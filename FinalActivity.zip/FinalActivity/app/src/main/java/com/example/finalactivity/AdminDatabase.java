package com.example.finalactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdminDatabase extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_database);
    }
}